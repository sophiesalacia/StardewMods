﻿
#### Splash Text
*by sophie*

Adds whimsical splash texts to the main menu, à la Minecraft.

[NexusMods]()  
[GitHub]()  

#### If you have any issues:
* Make sure SMAPI is up-to-date.
* You can reach me on the Stardew Valley discord (sophiesalacia#0001) or on the Nexus mod page.
* Please provide a SMAPI log, as well as your mod files, so that I can assist you better.
