﻿
#### Sturdy Saplings
*by sophie*

Removes ability of scythe to cut tree sprouts, ensuring that your precious saplings are safe from your wild flailing.

[NexusMods]()  
[GitHub]()  

#### If you have any issues:
* Make sure SMAPI is up-to-date.
* You can reach me on the Stardew Valley discord (sophiesalacia#0001) or on the Nexus mod page.
* Please provide a SMAPI log, as well as your mod files, so that I can assist you better.
